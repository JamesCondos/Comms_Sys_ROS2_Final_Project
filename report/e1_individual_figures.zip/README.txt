E1 figures: 11 separate plots, each supplied as PDF, PNG and SVG.
One plot per file; panel-letter prefixes have been removed.
See figure_guide.md for captions and the six main/five appendix selections.
Measurements are unchanged.
